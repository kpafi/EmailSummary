"""Domänen-Datenklassen (pydantic): RawMail, AttachmentInfo, SanitizedMail, SanitizationReport,
Summary, CriticVerdict, DigestMessage, FailureNotice.

Verbindliche Definition: docs/ARCHITECTURE.md §3 (umgesetzt in WP1).

Konventionen:
- `frozen=True` überall dort, wo ARCHITECTURE.md §3 es vorgibt. `Summary` und `CriticVerdict`
  bleiben bewusst veränderlich: Die deterministische Nachkontrolle (WP5/WP6) säubert Felder
  der LLM-Ausgabe in-place.
- `extra="forbid"`: Unbekannte Felder (z. B. aus LLM-JSON) werden abgelehnt statt still
  übernommen — Teil der Schema-Härtung (I4).
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "AttachmentInfo",
    "AttachmentKind",
    "CriticVerdict",
    "DigestMessage",
    "FailureNotice",
    "Importance",
    "PhishingRisk",
    "RawMail",
    "SanitizationReport",
    "SanitizedMail",
    "Summary",
]

#: Wichtigkeitsstufen einer Mail (Summarizer, F-SUM-2).
Importance = Literal["high", "normal", "low"]

#: Phishing-Risikostufen des Kritikers (F-CRIT-1).
PhishingRisk = Literal["none", "low", "high"]

#: Ergebnis der Magic-Bytes-Prüfung eines Anhangs (F-SEC-4).
AttachmentKind = Literal["pdf", "text", "html", "unknown", "mismatch"]


class RawMail(BaseModel):
    """Rohe Mail aus dem Mirror-Postfach (Stufe 1, Ingest).

    Enthält als einziges Modell die vollständigen MIME-Bytes. Dieses Objekt verlässt die
    Sanitize-Stufe nicht (I1) — siehe `pipeline.process_mail`.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    message_id: str | None = None
    dedupe_key: str
    from_addr: str
    from_domain: str
    reply_to: str | None = None
    #: Adresse (`addr_spec`) aus dem RFC-5322-Parser, leer wenn unbekannt (O-3). Der
    #: Sanitizer vergleicht damit — nicht mit einem zweiten `parseaddr` auf `from_addr`,
    #: das bei quotierten Lokalteilen (`"a["@…`) nichts liest und die Warnung stumm schaltete.
    from_address: str = ""
    #: Dasselbe für `Reply-To`: ``None`` = kein Header, ``""`` = vorhanden, aber unlesbar.
    reply_to_address: str | None = None
    #: Alle Adressaten des Reply-To laut Parser (Mailprogramme antworten an alle, O-3): ein
    #: Mismatch, sobald einer davon nicht die Absenderadresse ist. Angaben mit unbrauchbarer
    #: Domain (Domain-Literal, IDN) stehen als ``""`` darin — eine Unbekannte neben der
    #: bekannten Absenderadresse warnt. Angaben ohne Domain-Teil zählen nicht als Adressaten.
    reply_to_addresses: list[str] = Field(default_factory=list)
    return_path_domain: str | None = None
    to_addrs: list[str] = Field(default_factory=list)
    subject_raw: str = ""
    date: datetime | None = None
    auth_results_header: str | None = None
    mime_bytes: bytes
    size_bytes: int = Field(ge=0)
    #: SHA-256 (hex) über `mime_bytes` — das zweite, **nicht fälschbare** Dedupe-Merkmal
    #: neben dem frei wählbaren `Message-ID`-Header (ADR-079, HC-10). Leer nur bei
    #: von Hand gebauten `RawMail`-Objekten aus Tests.
    content_hash: str = ""
    #: Eine frühere Mail hat denselben Dedupe-Key, aber einen anderen Inhalt (ADR-079).
    #: Der Ingest setzt das Flag, der Sanitizer kopiert es in den `SanitizationReport`,
    #: der Composer macht daraus eine `🔍`-Hinweiszeile.
    id_collision: bool = False
    #: Der Ingest konnte diese Mail nicht auswerten (O-1): `build_raw_mail` ist trotz aller
    #: Absicherungen gescheitert, die Felder tragen nur, was überhaupt lesbar war, und
    #: `mime_bytes` ist ein Platzhalter. Die Pipeline schickt eine so markierte Mail ohne
    #: Umweg in den Fail-closed-Pfad (Metadaten-Notiz, Status `failed`); sie wird nie
    #: zusammengefasst. Nur der Ingest setzt das Flag.
    ingest_failed: bool = False


class AttachmentInfo(BaseModel):
    """Metadaten genau eines Anhangs — auch für nicht verarbeitete Anhänge (Allowlist, F-SEC-4)."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    filename_sanitized: str
    declared_mime: str
    detected_kind: AttachmentKind
    size_bytes: int = Field(ge=0)
    processed: bool = False
    extracted_chars: int = Field(default=0, ge=0)


class SanitizationReport(BaseModel):
    """Protokoll dessen, was der Sanitizer entfernt/ersetzt/erkannt hat (Stufe 2).

    Dient dem Nutzer als Hinweisblock und dem Kritiker als deterministische Faktenbasis
    (F-CRIT-3).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    links_removed: int = Field(default=0, ge=0)
    hidden_text_removed: bool = False
    control_chars_removed: int = Field(default=0, ge=0)
    punycode_domains: list[str] = Field(default_factory=list)
    mixed_script_domains: list[str] = Field(default_factory=list)
    truncated: bool = False
    #: `multipart/alternative` mit einem HTML-Teil, dessen Text inhaltlich deutlich vom
    #: ausgewerteten `text/plain`-Teil abweicht (CT-15, ADR-067). Mailprogramme zeigen den
    #: HTML-Teil — die Zusammenfassung beschriebe sonst unbemerkt einen anderen Inhalt.
    html_divergent: bool = False
    #: Ein `text/html`-Teil überschritt die Element-/Tiefenschranke der Konvertierung und
    #: gilt als **nicht verarbeitet** (ADR-084, HC2-1). Kein Fail-closed für die Mail: Der
    #: Klartext-Teil (falls vorhanden) wird normal zugestellt, der HTML-Teil nicht.
    html_rejected: bool = False
    #: Die Mail trug mehr Links, als eine einzelne Mail einzeln ausgewertet bekommt
    #: (`links.MAX_LINKS_PER_MAIL`, ADR-028-Nachtrag/R-5). Entfernt wurden sie alle (I3);
    #: die überzähligen tragen nur keinen Host und keine Fußnoten-Nummer mehr.
    links_capped: bool = False
    blocked_attachments: int = Field(default=0, ge=0)
    reply_to_mismatch: bool = False
    return_path_mismatch: bool = False
    #: Der `Message-ID`-Dedupe-Key dieser Mail war schon von einer inhaltlich anderen Mail
    #: belegt (ADR-079). Kopie von `RawMail.id_collision`; ohne diese Weitergabe bliebe die
    #: unterdrückte Mail für den Nutzer unsichtbar (HC-10).
    id_collision: bool = False
    #: So viele nachgebaute Datenblock-Marker (`<<<MAILDIGEST-…-UNTRUSTED-…>>>`) standen im
    #: Mail- oder Anhangstext (HC-5, ADR-061). Der Sanitizer erhebt das Faktum **vor** dem
    #: Tag-Stripper, der den Nachbau sonst spurlos entfernt; `> 0` setzt den
    #: Injection-Verdacht unabhängig von jeder Modellantwort (F-SEC-5).
    forged_markers: int = Field(default=0, ge=0)
    #: Die Mail war Ende-zu-Ende verschlüsselt (`multipart/encrypted`,
    #: `application/pkcs7-mime`, `application/pgp-encrypted`) — MailDigest entschlüsselt
    #: nicht (ADR-082). Kein Fehler und kein Risiko-Signal, sondern die Erklärung dafür,
    #: dass kein Inhalt da ist (HC-33).
    encrypted: bool = False
    auth_results: dict[str, str] = Field(default_factory=dict)


class SanitizedMail(BaseModel):
    """Ausgabe des Sanitizers: ausschließlich Klartext + Metadaten.

    Einziger Mail-Input, den ein LLM je zu sehen bekommt (I1).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    dedupe_key: str
    from_display: str
    from_domain: str
    subject: str
    date: datetime | None = None
    body_text: str
    attachment_texts: dict[str, str] = Field(default_factory=dict)
    attachments: list[AttachmentInfo] = Field(default_factory=list)
    links_found: list[str] = Field(default_factory=list)
    sanitization_report: SanitizationReport


class Summary(BaseModel):
    """Strukturierte Ausgabe des Summarizers (Stufe 3) — untrusted (I4).

    Bewusst nicht frozen: Die deterministische Nachkontrolle in WP5 säubert Felder und setzt
    `injection_suspected` nach.
    """

    model_config = ConfigDict(extra="forbid")

    headline: str = Field(max_length=100)
    summary_text: str
    importance: Importance
    importance_reason: str = ""
    category: str = ""
    attachment_summaries: dict[str, str] = Field(default_factory=dict)
    injection_suspected: bool = False


class CriticVerdict(BaseModel):
    """Ausgabe des Kritikers (Stufe 4) — untrusted (I4).

    Bewusst nicht frozen: analog zu `Summary` (deterministische Nachkontrolle in WP6).
    """

    model_config = ConfigDict(extra="forbid")

    phishing_risk: PhishingRisk
    risk_reasons: list[str] = Field(default_factory=list)
    summary_accurate: bool = True
    notes: str = ""


class DigestMessage(BaseModel):
    """Versandfertige, bereits output-sanitisierte Nachricht (Stufe 5).

    `parts` ist bereits auf die Längenbegrenzung des Ziel-Messengers gesplittet (WP7).
    Ab hier darf kein Text mehr verändert werden.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    parts: list[str]
    importance: Importance
    is_warning: bool = False
    dedupe_key: str


class FailureNotice(BaseModel):
    """Metadaten-Notiz für den Fail-closed-Pfad (I6, F-OPS-3).

    Enthält bewusst **keine** Mail-Inhalte und keine Fehlerdetails — nur Absender-Domain,
    not-sanitisierten Betreff, Stufe und grobe Fehlerklasse.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    dedupe_key: str
    from_domain: str
    subject_sanitized: str
    stage: str
    reason_class: str
